﻿namespace Image_Slideshow
{
    public partial class MainWindow
    {
        // Image List Model
        public class Images
        {
            public string name { get; set; }
            public string image { get; set; }
        }
    }
}