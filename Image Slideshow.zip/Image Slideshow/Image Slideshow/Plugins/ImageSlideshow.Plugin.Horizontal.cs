﻿using Image_Slideshow.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Image_Slideshow.Plugins.Horizontal
{
    public class HorizonalEffect : ISlideshowEffect
    {
        public string Name { get; }

        public void Play

    }
}