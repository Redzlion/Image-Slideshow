﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

public class VerticalEffect : ISlideshowEffect
{
    public string Name => "Vertical Effect";

    public void PlaySlideshow(Image imageIn, Image imageOut, double windowWidth, double windowHeight)
    {
        StoryboardIn(windowHeight, imageIn).Begin(imageIn);
        StoryboardOut(windowHeight, imageOut).Begin(imageOut);
    }

    private Storyboard StoryboardOut(double windowHeight, Image imageOut)
    {
        Storyboard sbOut = new Storyboard();

        DoubleAnimation VerticalOut = new DoubleAnimation
        {
            Duration = TimeSpan.FromSeconds(1),
            From = windowHeight,
            To = 0
        };

        Storyboard.SetTarget(VerticalOut, imageOut);
        Storyboard.SetTargetProperty(VerticalOut, new System.Windows.PropertyPath(FrameworkElement.HeightProperty));

        sbOut.Children.Add(VerticalOut);
        sbOut.Begin(imageOut);
        return sbOut;
    }

    private Storyboard StoryboardIn(double windowHeight, Image imageIn)
    {
        Storyboard sbIn = new Storyboard();
        DoubleAnimation VerticalIn = new DoubleAnimation
        {
            From = 0,
            To = windowHeight,
            Duration = TimeSpan.FromSeconds(1)
        };
        ThicknessAnimation ThicknessIn = new ThicknessAnimation()
        {
            Duration = TimeSpan.FromSeconds(1),
            From = new System.Windows.Thickness(0, windowHeight, 0, 0),
            To = new System.Windows.Thickness(0, 0, 0, 0)
        };

        Storyboard.SetTarget(VerticalIn, imageIn);
        Storyboard.SetTargetProperty(VerticalIn, new System.Windows.PropertyPath(FrameworkElement.HeightProperty));
        Storyboard.SetTarget(ThicknessIn, imageIn);
        Storyboard.SetTargetProperty(ThicknessIn, new System.Windows.PropertyPath(FrameworkElement.MarginProperty));

        sbIn.Children.Add(VerticalIn);
        sbIn.Children.Add(ThicknessIn);
        return sbIn;
    }
}